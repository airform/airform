// Match Layout Manually instead of auto resolver
import layout from './template';

// Use Module From Ember Global
export default Ember.Component.extend({
  layout
});
