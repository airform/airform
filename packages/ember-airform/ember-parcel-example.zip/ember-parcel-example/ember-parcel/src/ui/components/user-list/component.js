import Component from '@ember/component';
// Match Layout Manually instead of auto resolver
import layout from './template';


// Use Module From Ember Global
export default Component.extend({
  layout
});
